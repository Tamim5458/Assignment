package Lecture_8;
//example - 6

public class Girl {
    public void eat(){
        System.out.println("Hey girls eat more and more");
    }

    public static void main(String[] args) {
        Girl girl1= new Girl();
        girl1.eat();
    }
}
