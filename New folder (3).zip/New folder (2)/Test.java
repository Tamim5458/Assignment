public class Test {
    public static void main(String[] args) {
        Box box1 = new Box();
        box1.setInformation(12,45);
        box1.dispalyinfomation();
    }
}
