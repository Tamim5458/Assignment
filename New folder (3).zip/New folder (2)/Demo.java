public class Demo {
    public Demo(){
        System.out.println (" nothing ");
    }

    public static void main(String[] args) {
        Demo d = new Demo ();

    }
}
