package Lecture_8;

public class A {
    int x = 5;
    public void display(){
        System.out.println("Inside a class");
    }
    public A(){
        System.out.println("A is a constractor");
    }
}
