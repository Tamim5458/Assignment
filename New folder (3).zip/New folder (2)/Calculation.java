package Lecture_8;
//Example - 4
public class Calculation {
    int z;
    public void addition(int x,int y){
        z= x+y;
        System.out.println("addition :"+z);
    }
    public void subtraction(int x,int y){
        z = x-y;
        System.out.println("Substraction :"+z);
    }

}
