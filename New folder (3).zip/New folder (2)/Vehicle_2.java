package Lecture_8;

public class Vehicle_2 {
 int speed = 50;

}
