public class Box {
    int height, width;


    void setInformation(int h, int w) {
        height = h;
        width = w;

    }

    void dispalyinfomation() {


        System.out.println("the height of the box1: "+height);
        System.out.println("the width of the box2 :"+width);
    }

}