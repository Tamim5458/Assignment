package Lecture_8;
//Example - 6
public class Human {
    public void eat(){
        System.out.println("Ok bye Human");
    }
}
