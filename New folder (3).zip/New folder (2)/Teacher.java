package Lecture_8;
//Example - 2
public class Teacher {
    String designation= "Lecturer";
    String uniName = "DIU";
    public void job(){
        System.out.println("Teaching ");
    }

}
